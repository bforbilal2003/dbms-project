# import psycopg2
# from configparser import ConfigParser

# def config(filename='database.ini', section='postgresql'):
#     parser = ConfigParser()
#     parser.read(filename)

#     db = {}
#     if parser.has_section(section):
#         params = parser.items(section)
#         for param in params:
#             db[param[0]] = param[1]
#     else:
#         raise Exception('Section {0} not found in the {1} file'.format(section, filename))

#     return db

# def connect():
#     connection = None
#     try:
#         params = config()
#         print('Connecting to the PostgreSQL database...')
#         connection = psycopg2.connect(**params)
#         return connection
#     except (Exception, psycopg2.DatabaseError) as error:
#         print(error)

# def User_reg(connection):
#     try:
#         email = input("Enter Email: ")
#         name = input("Enter Name: ")
#         password = input("Enter Password: ")
        
#         cursor = connection.cursor()
#         cursor.execute("INSERT INTO User1 (email, name, password) VALUES (%s, %s, %s)",
#                        (email, name, password))
#         connection.commit()
#         print("Added User successfully.")
#     except (psycopg2.Error, ValueError) as error:
#         print("Error while adding user:", error)

# def get_room_info(connection, room_type):
#     try:
#         cursor = connection.cursor()
#         query = f"SELECT price, isAvailable, maxNoOfPeople FROM {room_type}"
#         print("Executing query:", query)  # Print the query being executed
#         cursor.execute(query)
#         room_info = cursor.fetchone()
#         if room_info:
#             return room_info
#         else:
#             print("No room information found for the specified room type.")
#             return None
#     except psycopg2.Error as e:
#         print("Error fetching room information:", e)
#         return None

# def add_reservation(connection):
#     try:
#         room_type = input("Enter Room Type (delux/premium/suite): ")
        
#         # Fetch room information based on room type
#         room_info = get_room_info(connection, room_type)
#         if room_info:
#             price, is_available, max_people = room_info
#             print(f"Price: {price}, Is Available: {is_available}, Max Number of People: {max_people}")
#         else:
#             print("Room type not found or error fetching room information.")
#             return
        
#         reservationID = input("Enter Reservation ID: ")
#         reservedBy = input("Enter Reserved By (email): ")
#         reservationDate = input("Enter Reservation Date (YYYY-MM-DD): ")
#         checkoutDate = input("Enter Checkout Date (YYYY-MM-DD): ")
        
#         cursor = connection.cursor()
#         cursor.execute("INSERT INTO reservation(reservationID, reservedBy, roomType, reservationDate, checkoutDate) VALUES (%s, %s, %s, %s, %s)",
#                       (reservationID, reservedBy, room_type, reservationDate, checkoutDate))
#         connection.commit()
#         print("Added Reservation successfully.")
#     except (psycopg2.Error, ValueError) as error:
#         print("Error while adding reservation:", error)

# def main():
#     connection = connect()
#     if connection:
#         while True:
#             print("\nHOSTEL MANAGER")
#             print("1. ADD NEW USER")
#             print("2. Add Reservation")
#             print("3. EXIT")

#             choice = input("Enter your choice: ")

#             if choice == '1':
#                 User_reg(connection)
#             elif choice == '2':
#                 add_reservation(connection)
#             elif choice == '3':
#                 connection.close()
#                 print("Database connection terminated.")
#                 break
#             else:
#                 print("Invalid choice. Please try again.")

# if __name__ == "__main__":
#     main()

####################################################################################





##################################(front end)#########################################


# from flask import Flask, render_template, request, redirect
# import psycopg2
# from configparser import ConfigParser

# app = Flask(__name__)

# def config(filename='database.ini', section='postgresql'):
#     parser = ConfigParser()
#     parser.read(filename)

#     db = {}
#     if parser.has_section(section):
#         params = parser.items(section)
#         for param in params:
#             db[param[0]] = param[1]
#     else:
#         raise Exception('Section {0} not found in the {1} file'.format(section, filename))

#     return db

# def User1(email, name, password):
#     try:
#         connection = psycopg2.connect(**config('database.ini'))
#         cursor = connection.cursor()
#         cursor.execute("INSERT INTO User1 (email, name, password) VALUES (%s, %s, %s)",
#                        (email, name, password))
#         connection.commit()
#         cursor.close()
#         connection.close()
        
#         return True, "User added successfully."
#     except (psycopg2.Error, ValueError) as error:
#         return False, f"Error while adding user: {error}"
    

# def add_reservation(reservationID, reservedBy, roomType, reservationDate, checkoutDate):
#     try:
#         connection = psycopg2.connect(**config('database.ini'))
#         cursor = connection.cursor()
#         cursor.execute("INSERT INTO reservation (reservationID, reservedBy, roomType, reservationDate, checkoutDate) VALUES (%s, %s, %s, %s, %s)",
#                        (reservationID, reservedBy, roomType, reservationDate, checkoutDate))
#         connection.commit()
#         cursor.close()
#         connection.close()
        
#         return True, "Reservation added successfully."
#     except (psycopg2.Error, ValueError) as error:
#         return False, f"Error while adding reservation: {error}"
    


# @app.route('/')
# def index():
#     return render_template('index.html')

# @app.route('/add_user', methods=['POST'])
# def add_user():
#     email = request.form['email']
#     name = request.form['name']
#     password = request.form['password']
    
#     success, message = User1(email, name, password)
#     if success:
#         return redirect('/', code=302)
#     else:
#         return message
    

# @app.route('/add_reservation', methods=['POST'])
# def add_reservation_route():
#     reservationID = request.form['reservationID']
#     reservedBy = request.form['reservedBy']
#     roomType = request.form['roomType']
#     reservationDate = request.form['reservationDate']
#     checkoutDate = request.form['checkoutDate']
    
#     success, message = add_reservation(reservationID, reservedBy, roomType, reservationDate, checkoutDate)
#     if success:
#         return redirect('/', code=302)
#     else:
#         return message


# if __name__ == '__main__':
#     app.run(debug=True)



from flask import Flask, render_template, request, redirect
import psycopg2
from configparser import ConfigParser

app = Flask(__name__)

def config(filename='database.ini', section='postgresql'):
    parser = ConfigParser()
    parser.read(filename)

    db = {}
    if parser.has_section(section):
        params = parser.items(section)
        for param in params:
            db[param[0]] = param[1]
    else:
        raise Exception('Section {0} not found in the {1} file'.format(section, filename))

    return db

def User1(email, name, password):
    try:
        connection = psycopg2.connect(**config('database.ini'))
        cursor = connection.cursor()
        cursor.execute("INSERT INTO User1 (email, name, password) VALUES (%s, %s, %s)",
                       (email, name, password))
        connection.commit()
        cursor.close()
        connection.close()
        
        return True, "User added successfully."
    except (psycopg2.Error, ValueError) as error:
        return False, f"Error while adding user: {error}"
    

def add_reservation(reservationID, reservedBy, roomType, reservationDate, checkoutDate):
    try:
        connection = psycopg2.connect(**config('database.ini'))
        cursor = connection.cursor()
        cursor.execute("INSERT INTO reservation (reservationID, reservedBy, roomType, reservationDate, checkoutDate) VALUES (%s, %s, %s, %s, %s)",
                       (reservationID, reservedBy, roomType, reservationDate, checkoutDate))
        connection.commit()
        cursor.close()
        connection.close()
        
        return True, "Reservation added successfully."
    except (psycopg2.Error, ValueError) as error:
        return False, f"Error while adding reservation: {error}"

def get_reservation_details(reservation_id):
    try:
        connection = psycopg2.connect(**config('database.ini'))
        cursor = connection.cursor()
        cursor.execute("SELECT * FROM reservation WHERE reservationID = %s", (reservation_id,))
        reservation_details = cursor.fetchone()
        cursor.close()
        connection.close()
        
        return reservation_details
    except (psycopg2.Error, ValueError) as error:
        return None
    

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/add_user', methods=['POST'])
def add_user():
    email = request.form['email']
    name = request.form['name']
    password = request.form['password']
    
    success, message = User1(email, name, password)
    if success:
        return redirect('/', code=302)
    else:
        return message
    

@app.route('/add_reservation', methods=['POST'])
def add_reservation_route():
    reservationID = request.form['reservationID']
    reservedBy = request.form['reservedBy']
    roomType = request.form['roomType']
    reservationDate = request.form['reservationDate']
    checkoutDate = request.form['checkoutDate']
    
    success, message = add_reservation(reservationID, reservedBy, roomType, reservationDate, checkoutDate)
    if success:
        return redirect('/', code=302)
    else:
        return message

@app.route('/reservation_details', methods=['POST'])
def reservation_details():
    reservation_id = request.form['reservation_id']
    reservation_details = get_reservation_details(reservation_id)
    if reservation_details:
        return render_template('reservation_details.html', reservation=reservation_details)
    else:
        return "Reservation not found."

if __name__ == '__main__':
    app.run(debug=True)
